Welcome to the IMS Basic LTI Playground

This has several different parts:

- lms.php - a simple IMS Basic LTI Tool Consumer that can be used to test
Basic LTI Tool Producers

- tool.php - a simple IMS Basic LTI Tool Producer - used to 
test Tool Consumers

- adlist/ - a complete application using IMS Basic LTI to implement
a multi-tenancy classified-ad application.  This has a full database
and an administrator interface to set keys.  The documentation for
this application is in adlist/index.htm

- ims-blti/ - The IMS Basic LTI client libraries used by all of these applications

/Chuck
www.dr-chuck.com

Sun Jun  6 08:55:48 EDT 2010
