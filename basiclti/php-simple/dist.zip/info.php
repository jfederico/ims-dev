<?php 
  phpinfo();
?>
